import React from "react";
import Entry from "./Entry";
import emojipedias from "../emojipedia";

function createEntry(emojipedia) {
  return (
    <Entry
      emoji={emojipedia.emoji}
      name={emojipedia.name}
      disc={emojipedia.meaning}
    />
  );
}
function App() {
  return (
    <div>
      <h1>
        <span>emojipedia</span>
      </h1>
      <dl className="dictionary">
        {emojipedias.map(createEntry)}
        <Entry
          emoji={emojipedias[0].emoji}
          name={emojipedias[0].name}
          disc={emojipedias[0].meaning}
        />
        <Entry
          emoji={emojipedias[1].emoji}
          name={emojipedias[1].name}
          disc={emojipedias[1].meaning}
        />
        <Entry
          emoji={emojipedias[2].emoji}
          name={emojipedias[2].name}
          disc={emojipedias[2].meaning}
        />
      </dl>
    </div>
  );
}

export default App;
