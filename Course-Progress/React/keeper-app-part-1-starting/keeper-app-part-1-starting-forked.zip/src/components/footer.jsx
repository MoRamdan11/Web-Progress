import React from "react";

var currentDate = new Date();
var currentYear = currentDate.getFullYear();
function footer() {
  return (
    <footer>
      <p>Copyright &copy; {currentYear}</p>
    </footer>
  );
}

export default footer;
