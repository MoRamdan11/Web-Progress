import React from "react";

function Header() {
  return <header>Moheamed</header>;
}

export default Header;
