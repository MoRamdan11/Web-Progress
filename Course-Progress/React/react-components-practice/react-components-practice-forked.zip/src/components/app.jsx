import React from "react";
import Heading from "./heading";

function App() {
  return <Heading />;
}

export default App;
